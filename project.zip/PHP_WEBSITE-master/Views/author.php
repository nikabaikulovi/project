
    <div class="card-body bg-dark">
            <img src="public/images/adm.jpg" class="card-img-top img-thumbnail" style="width:300px"  >
            <div style="height: 20px"></div>
            <ul class="list-group list-group-black">
                <li class="list-group-item">Roman Chikhladze</li>
                <li class="list-group-item"><a href="https://www.facebook.com/profile.php?id=100008242515249">Facebook</a></li>
                <li class="list-group-item"><a href="https://www.instagram.com/romachikhladze.1/">Instagram</a></li>
                <li class="list-group-item"><a href="https://github.com/romashka1999">Github</a></li>
            </ul>
    </div>
