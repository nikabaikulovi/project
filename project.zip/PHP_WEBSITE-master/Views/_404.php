<div class="alert alert-warning">
    <h1>404 - Requested page does not exist</h1>
</div>
