# PHP gambling website

## Getting Started

This website is for fun 

### Installing

```
1) open terminal and run command 'composer install'
```
```
2) Run db/migrations.php file to create database and users table
```
```
3) Go to the bin folder start php server by running command php '-S 127.0.0.1:8000' or you can setup the apache virtual host and run it just like this
```
## Author

* **Roman Chikhladze** 




