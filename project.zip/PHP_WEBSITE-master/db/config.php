<?php
/**
 * User: TheCodeholic
 * Date: 5/5/2019
 * Time: 6:26 PM
 */
return [
    'host' => 'localhost',
    'username' => 'root',
    'password' => '',
    'database' => 'project'
];
